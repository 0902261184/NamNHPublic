﻿var myapp;
(function () {

    myapp = angular.module('my-employees', ['toaster', 'ngAnimate', 'ui.bootstrap.showErrors']);

})();